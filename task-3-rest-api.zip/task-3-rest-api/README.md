# Student Management REST API

## Task 3 – REST API Development

A simple RESTful API developed using Python Flask and SQLite for managing student records.

## Technologies

- Python
- Flask
- SQLite
- REST API
- JSON
- Postman / Thunder Client
- Git and GitHub

## Features

- Create student
- Get all students
- Get student by ID
- Update student
- Delete student
- Input validation
- Error handling
- JSON responses
- SQLite database integration

## Project Structure

```text
task-3-rest-api/
├── app.py
├── requirements.txt
├── README.md
└── docs/
    └── API_DOCUMENTATION.md
```

## Database Model

| Field | Type | Description |
|---|---|---|
| id | INTEGER | Primary key |
| name | TEXT | Student name |
| email | TEXT | Unique student email |
| course | TEXT | Student course |
| age | INTEGER | Student age |

The `students.db` file is created automatically when the application starts.

## Installation

### 1. Create a virtual environment

```bash
python -m venv venv
```

### 2. Activate it on Windows

```bash
venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
python app.py
```

API URL:

```text
http://127.0.0.1:5000
```

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Check API status |
| POST | `/students` | Create student |
| GET | `/students` | Get all students |
| GET | `/students/<id>` | Get student by ID |
| PUT | `/students/<id>` | Update student |
| DELETE | `/students/<id>` | Delete student |

## Create Student

**POST `/students`**

```json
{
    "name": "Radhika",
    "email": "radhika@example.com",
    "course": "Computer Science",
    "age": 21
}
```

Response:

```json
{
    "message": "Student created successfully",
    "student_id": 1
}
```

## Get All Students

**GET `/students`**

Example response:

```json
[
    {
        "id": 1,
        "name": "Radhika",
        "email": "radhika@example.com",
        "course": "Computer Science",
        "age": 21
    }
]
```

## Update Student

**PUT `/students/1`**

```json
{
    "name": "Radhika Updated",
    "email": "radhika.updated@example.com",
    "course": "Data Science",
    "age": 22
}
```

## Delete Student

**DELETE `/students/1`**

Response:

```json
{
    "message": "Student deleted successfully"
}
```

## Validation

The API validates:

- Required fields
- Age data type
- Age value
- Duplicate email addresses
- Student ID existence
- JSON request body

## HTTP Status Codes

| Code | Meaning |
|---|---|
| 200 | Successful request |
| 201 | Resource created |
| 400 | Bad request |
| 404 | Resource not found |
| 500 | Internal server error |

## Documentation

Detailed API documentation:

`docs/API_DOCUMENTATION.md`

## GitHub Upload

```bash
git init
git add .
git commit -m "Task 3 REST API Development"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Deliverables

- Flask REST API
- SQLite database integration
- CRUD operations
- Input validation
- Error handling
- JSON responses
- API documentation
- README
- GitHub-ready project
