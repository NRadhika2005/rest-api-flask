# Student Management REST API – API Documentation

## Base URL

```text
http://127.0.0.1:5000
```

## 1. API Status

### GET `/`

Checks whether the API is running.

Response:

```json
{
    "message": "Welcome to Student Management REST API",
    "status": "API is running"
}
```

Status: `200 OK`

---

## 2. Create Student

### POST `/students`

Creates a new student.

### Headers

```text
Content-Type: application/json
```

### Request Body

```json
{
    "name": "Radhika",
    "email": "radhika@example.com",
    "course": "Computer Science",
    "age": 21
}
```

### Response

```json
{
    "message": "Student created successfully",
    "student_id": 1
}
```

Status: `201 Created`

### Validation Error

```json
{
    "error": "email is required"
}
```

Status: `400 Bad Request`

---

## 3. Get All Students

### GET `/students`

Returns all students.

### Response

```json
[
    {
        "id": 1,
        "name": "Radhika",
        "email": "radhika@example.com",
        "course": "Computer Science",
        "age": 21
    }
]
```

Status: `200 OK`

---

## 4. Get Student by ID

### GET `/students/<id>`

Example:

```text
GET /students/1
```

### Response

```json
{
    "id": 1,
    "name": "Radhika",
    "email": "radhika@example.com",
    "course": "Computer Science",
    "age": 21
}
```

Status: `200 OK`

If the student does not exist:

```json
{
    "error": "Student not found"
}
```

Status: `404 Not Found`

---

## 5. Update Student

### PUT `/students/<id>`

Example:

```text
PUT /students/1
```

### Request Body

```json
{
    "name": "Radhika Updated",
    "email": "radhika.updated@example.com",
    "course": "Data Science",
    "age": 22
}
```

### Response

```json
{
    "message": "Student updated successfully"
}
```

Status: `200 OK`

---

## 6. Delete Student

### DELETE `/students/<id>`

Example:

```text
DELETE /students/1
```

### Response

```json
{
    "message": "Student deleted successfully"
}
```

Status: `200 OK`

---

## Database Model

### Table: students

| Field | Data Type | Constraint |
|---|---|---|
| id | INTEGER | Primary Key |
| name | TEXT | NOT NULL |
| email | TEXT | UNIQUE, NOT NULL |
| course | TEXT | NOT NULL |
| age | INTEGER | NOT NULL |

## Validation Rules

- Name is required.
- Email is required and must be unique.
- Course is required.
- Age must be an integer.
- Age must be greater than 0.
- Student ID must exist for GET, PUT, and DELETE.

## HTTP Status Codes

| Code | Description |
|---|---|
| 200 | Successful request |
| 201 | Resource created |
| 400 | Bad request |
| 404 | Student or route not found |
| 500 | Internal server error |

## CRUD Summary

```text
CREATE
POST /students

READ
GET /students
GET /students/<id>

UPDATE
PUT /students/<id>

DELETE
DELETE /students/<id>
```

This API fulfills the required CRUD functionality for Task 3.
